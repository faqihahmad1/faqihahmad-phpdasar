<?php 
session_start();
$koneksi = mysqli_connect('localhost', 'root', '', 'digital_perpus');